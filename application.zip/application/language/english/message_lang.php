<?php
//Bahasa Inggris


//navbar and side nav
$lang["HOME"] = "Home";
$lang["INFORMATION"] = "Information";
$lang["EVENT"] = "Event";
$lang["REGISTRATION"] = "REGISTRATION";
$lang["LANGUAGE"] = "language";

//INDEX
$lang["TITLE1"] = "WHAT IS CREATONOMICS ?";
$lang["DESC1"] = "Creatonomics Business Creativity Competition (CBCC) is an event by Management, Faculity of Economics and Business, Brawijaya University which has two main events, competition and education to push sustainable entrepreneurial spirit in strenghtening creative economy in Indonesia with the grand theme “Millenials Disruptive Creativity";

$lang["TITLE2"] = "EVENT";
$lang["COMPETITION"] = "COMPETITION";
$lang["EDUCATION"] = "EDUCATION";
$lang["COMP-DESC"] = "Business idea competition from 16 categories also known as 16 Economic’s Creative Sub-Sectors, which themed “Millenials Disruptive Creaitivity";
$lang["EDU-DESC"] = "Education is one of the main event in CBCC. The education form in here is SEMINAR which this year topic is  Creativepreneurship and Sustainopreneurship";

$lang["TITLE3"] = "INFORMATION";


//FOOTER
$lang["CONTACT-US"] = "CONTACT US";
$lang["LINE1"] = "Committee of CBCC 2018";
$lang["LINE2"] = "Entrepreneurship Program, Management Departement";
$lang["LINE3"] = "Faculty of Economics and Business, University of Brawijaya";
$lang["LINE4"] = "First Floor D. Building - Jl. MT. Haryono 165, Malang 65145, East Java";
$lang[""] = "";

//EVENT
$lang["DESCRIPTION"] = "DESCRIPTION";
$lang["DATE"] = "DATE";
$lang["REQUIREMENTS"] = "REQUIREMENTS";
$lang["REGISTRATION"] = "REGISTRATION";
$lang["ATTACHMENT"] = "ATTACHMENT";

$lang["DESC-COMP"] = "Kompetisi ide bisnis CBCC adalah salah satu acara utama CBCC. Dalam ide bisnis ini diharapkan dapat menangkap ide bisnis kreatif sesuai dengan 16 sub-sektor ekonomi kreatif yang bisa dikembangkan dengan melakukan presentasi dengan teknik pitching oleh semua peserta. 16 sub-sektor tersebut adalah :";
$lang["DESC-COMP-LIST"] = 
		"<ol>
			<li>Apps and Game Developers</li>
			<li>Architecture</li>
			<li>Interior Design</li>
			<li>Visual Communication Design</li>
			<li>Product Design</li>
			<li>Fashion</li>
			<li>Movies, Animations, Videos</li>
			<li>Photography</li>
			<li>Craft</li>
			<li>Culinary</li>
			<li>Music</li>
			<li>Publishing</li>
			<li>Advertising</li>
			<li>The Performing Arts</li>
			<li>Arts</li>
			<li>Television and radio</li>
		</ol>";

$lang["DATE-TITLE"] = "Dates :";
$lang["DATE-LIST"] = "								
	<ol>
		<li style='margin-bottom: 10px;''>Online Registration and Video Submission (free): March 16th  – April 16th 2018</li>
		<li style='margin-bottom: 10px;'>Qualification process: April 17th – 19th 2018</li>
		<li style='margin-bottom: 10px;'>Announcement for big 60: April 20th 2018</li>
		<li style='margin-bottom: 10px;'>Re-registration: April 22nd – 27th 2018</li>
		<li style='margin-bottom: 10px;'>Welcoming dinner & Technical Meeting: May 1st 2018</li>
		<li style='margin-bottom: 10px;'>Preliminary Round: May 2nd 2018</li>
		<li style='margin-bottom: 10px;'>Seminar & Final Round: May 3rd 2018</li>
	</ol>";
$lang[""] = "";
$lang[""] = "";
$lang[""] = "";
$lang[""] = "";
$lang[""] = "";
$lang[""] = "";



