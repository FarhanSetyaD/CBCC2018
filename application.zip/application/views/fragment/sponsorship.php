<div class="">
	<div class="container">
		<div class="section">
			<div class="row">
				<div class="col s6">
					<h4 class="center-align font yellow-text text-darken-2"><b>SPONSORSHIP</b></h4>
					<hr class="hr" style="border:solid rgba(0,0,0,0.20) 2px;">
				</div>
				<div class="col s6">
					<h4 class="center-align font yellow-text text-darken-2"><b>MEDIA PARTNER</b></h4>
					<hr class="hr" style="border:solid rgba(0,0,0,0.20) 2px;">
				</div>
			</div>
			<div class="row">
				<div class="col s12">
					
				</div>
			</div>
		</div>
	</div>
</div>