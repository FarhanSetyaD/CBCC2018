<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1"/>
<link rel="shortcut icon" type="image/x-icon" href="favicon.ico" />
<title>Creatonomics</title>

<!-- CSS -->
<link href="https://fonts.googleapis.com/css?family=Raleway:400,800" rel="stylesheet">
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<link href="<?php echo base_url();?>assets/css/materialize.css" type="text/css" rel="stylesheet" media="screen,projection"/>
<link href="<?php echo base_url();?>assets/css/owl.carousel.min.css" type="text/css" rel="stylesheet" media="screen,projection"/>
<link href="<?php echo base_url();?>assets/css/font-awesome.min.css" type="text/css" rel="stylesheet" media="screen,projection"/>
<link href="<?php echo base_url();?>assets/css/style.css" type="text/css" rel="stylesheet" media="screen,projection"/>
<link href="<?php echo base_url();?>assets/plugin/data-tables/css/jquery.dataTables.min.css" type="text/css" rel="stylesheet" media="screen,projection"/>

