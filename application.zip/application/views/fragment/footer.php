<footer class="page-footer blue">
	<div class="container">
		<div class="row">
			<h4 class="center-align font yellow-text text-darken-2"><b>CONTACT US</b></h4>
			<hr class="hr" style="border:solid rgba(0,0,0,0.20) 2px;">
		</div>
		<div class="row">
      		<div class="col s12 center-align" style="margin-bottom: 40px;">
				<a class="white-text" href="https://www.instagram.com/creatonomics/" target="_blank"><i style="margin-left: 5px;margin-right: 5px;" class="fa fa-instagram fa-3x"></i></a>
       			<a class="white-text" href="https://www.facebook.com/creatonomics/" target="_blank"><i style="margin-left: 5px;margin-right: 5px;" class="fa fa-facebook-square fa-3x"></i></a>
       			<a class="white-text" href="https://line.me/ti/p/~@creatonomics" target="_blank"><i style="margin-left: 5px;margin-right: 5px;"><img src="<?php echo base_url();?>assets/Image/line.png" alt="" width="39px;" style="position: relative; top: 4px;"></i></a>
       			<a class="white-text" href="https://twitter.com/creatonomics" target="_blank"><i style="margin-left: 5px;margin-right: 5px;" class="fa fa-twitter-square fa-3x"></i></a>
        	</div>
        	
       		<div class="col s12 center-align">
       			<p style="margin-top: -10px">Committee of CBCC 2018<br>Entrepreneurship Program, Management Departement<br>Faculty of Economics and Business, University of Brawijaya<br>First Floor D. Building - Jl. MT. Haryono 165, Malang 65145, East Java</p>
       		</div>
      	</div>
    </div>
    <div class="footer-copyright">
     	<div class="container center-align">
      		&copy; CBCC Heroes 2018
      	</div>
    </div>
</footer>