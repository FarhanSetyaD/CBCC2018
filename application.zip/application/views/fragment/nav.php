<div class="navbar-fixed">
  <nav class="white" style="background-color: #026AB0">
      <a id="logo-container" href="<?php echo base_url();?>" class="brand-logo font yellow-text logo-pojok"><img src="<?php echo base_url();?>assets/Image/logo7.png" height="40px;"></a>
      <ul class="right hide-on-med-and-down" style="margin-right: 20px;">
        <li><a class="yellow-text text-darken-2 font" href="<?php echo base_url();?>"><i class="material-icons left" style="margin-top: 3px">home</i>Home</a></li>
        <li><a class="yellow-text text-darken-2 font" href="<?php echo base_url();?>index.php/Informasi"><i class="material-icons left" style="margin-top: 4px">assignment</i>Information</a></li>
        <li><a class="yellow-text text-darken-2 font" href="<?php echo base_url();?>index.php/Event"><i class="material-icons left" style="margin-top: 3px">extension</i>Event</a></li>
        <li><a class="waves-effect waves-light btn grey" href="<?php echo base_url();?>index.php/Daftar">
            Daftar Seminar</a></li>
        <li><a class="waves-effect waves-light btn grey" href="<?php echo base_url();?>index.php/Daftar">Re-registration</a></li>
        <li><a class="waves-effect waves-light btn grey" href="<?php echo base_url();?>index.php/Daftar">Registration</a></li>
 
      </ul>
      <a href="#" data-activates="nav-mobile" class="button-collapse"><i class="material-icons black-text">menu</i></a>
  </nav>
</div>
 
<ul id="nav-mobile" class="side-nav" style="background-color: #003368">

  <li><div class="user-view" style="height: 120px;">
    <div class="background">
      <img src="<?php echo base_url();?>assets/Image/header-menu.jpg" style="width: 100%">
    </div>
  </div></li>
  <li class="font"><a class="white-text" href="<?php echo base_url();?>"><i class="material-icons white-text">home</i><b>Home</b></a></li>
  <li class="font"><a class="white-text" href="<?php echo base_url();?>index.php/Informasi"><i class="material-icons white-text">assignment</i><b>Information</b></a></li>
  <li class="font"><a class="white-text" href="<?php echo base_url();?>index.php/Event"><i class="material-icons white-text">extension</i><b>Event</b></a></li>
  <li><a class="waves-effect waves-light btn yellow darken-2 cbcc-text" href="http://bit.ly/PendaftaranSeminarCBCC2018">
            daftar seminar</a></li>
    <li><a class="waves-effect waves-light btn grey" href="<?php echo base_url();?>index.php/Daftar">Re-registration</a></li>
  <li><a class="waves-effect waves-light btn grey" href="<?php echo base_url();?>index.php/Daftar">Registration</a></li>
</ul>