<!DOCTYPE html>
<html>  
<?php
echo '<script>alert("We are sorry, resgistration are closed")</script>';
                	redirect(base_url(),'refresh');
?>
</html>